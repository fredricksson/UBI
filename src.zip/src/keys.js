module.exports = {
    mongoDB : {
        url: 'mongodb://localhost/stores'
    }
}