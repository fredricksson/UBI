const express = require('express')
const router = express.Router()
const authMiddleware = require('../middleware/auth')
const storyController = require('../controllers/storyController')

router.use(authMiddleware)

router.post('/create', storyController.create )
router.put('/update/:id', storyController.update )

module.exports = router